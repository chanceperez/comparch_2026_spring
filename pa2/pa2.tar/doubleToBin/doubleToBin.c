#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>

#define EXP_SZ 11
#define FRAC_SZ 52

int main(int argc, char *argv[]) // Was working and now doesn't for some reason?? Confused...
{

    // SETUP

    FILE *fp = fopen(argv[1], "r");
    if (!fp)
    {
        perror("fopen failed");
        return 0;
    }

    // first, read the number
    double value;
    fscanf(fp, "%lf", &value);

    // the reference solution ('the easy way')
    // you are not allowed to print from this casted 'ref_bits' variable below
    // but, it is helpful for validating your solution
    unsigned long int ref_bits = *(unsigned long int *)&value;

    // THE SIGN BIT
    bool sign = value < 0.0; // 1 if less than 0 (neg) 0 if not (pos)
    printf("%d_", sign);
    assert(sign == (1 & ref_bits >> (EXP_SZ + FRAC_SZ))); // validate your result against the reference

    // THE EXP FIELD
    // find the exponent E such that the fraction will be a canonical fraction:
    // 1.0 <= fraction < 2.0
    double fraction = sign ? -value : value;

    signed int trial_exp = (1 << (EXP_SZ - 1)) - 1; // start by assuming largest possible exp (before infinity) //signed int bc of (maybe) over/underflow
    if (fraction == 0)
    {
        printf("00000000000_0000000000000000000000000000000000000000000000000000"); // error was because I already printed sign with _
        return 0;
    }

    // do trial division until the proper exponent E is found
    while (fraction < 1 || fraction >= 2) // searches for the exponent through loop
    {
        if (fraction >= 2)
        {
            fraction /= 2;
            trial_exp += 1; // divide by 2 increase by 1
        }
        else
        {
            fraction *= 2;
            trial_exp -= 1; // double and decrease exponent
        }
    }

    signed int exp = trial_exp;

    for (int exp_index = EXP_SZ - 1; 0 <= exp_index; exp_index--)
    {
        bool exp_bit = 1 & exp >> exp_index;
        printf("%d", exp_bit);
        assert(exp_bit == (1 & ref_bits >> (exp_index + FRAC_SZ))); // validate your result against the reference
    }
    printf("_");
    // you get partial credit by getting the exp field correct
    // even if you print zeros for the frac field next
    // you should be able to pass test cases 0, 1, 2, 3

    // THE FRAC FIELD
    // prepare the canonical fraction such that:
    // 1.0 <= fraction < 2.0
    fraction -= 1;

    bool frac_array[FRAC_SZ + 1]; // one extra LSB bit for rounding
    for (int frac_index = FRAC_SZ; frac_index >= 0; frac_index--)
    {
        frac_array[frac_index] = false; // frac set to zero to enable partial credit
        fraction *= 2;
        if (fraction >= 1)
        {
            frac_array[frac_index] = true;
            fraction -= 1; // leftover
        }
    }

    // rounding
    if (frac_array[0])
    {
        bool carry = true;
        for (int i = 1; i <= 52; i++)
        {
            if (!carry)
                break;
            bool newCarry = frac_array[i] && carry;
            frac_array[i] = frac_array[i] != carry;
            carry = newCarry;
        }
    }

    for (int frac_index = 52; frac_index >= 1; frac_index--)
    {
        bool frac_bit = frac_array[frac_index]; // skipping the extra LSB bit for rounding
        printf("%d", frac_bit);

        assert(frac_bit == (1 & ref_bits >> (frac_index - 1))); // validate your result against the reference //moving this number by -1 so I can go from 52 to 1
    }
}

/* RESOURCES */

/*
double precision - https://www.geeksforgeeks.org/computer-organization-architecture/ieee-standard-754-floating-point-numbers/
*/